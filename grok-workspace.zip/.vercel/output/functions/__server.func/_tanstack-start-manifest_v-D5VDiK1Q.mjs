//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D5VDiK1Q.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/hq",
			"/about",
			"/achievements",
			"/gallery",
			"/insights",
			"/login",
			"/matches",
			"/squad",
			"/api/auth/$",
			"/api/media/$id"
		],
		preloads: [
			"/assets/index-BeqTD_ES.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-BMDdmtEl.js",
			"/assets/constants-BRw5T-he.js",
			"/assets/root-DLTE-HSj.js",
			"/assets/public-Dssp1VK0.js",
			"/assets/useNavigate-BVBKrbSk.js",
			"/assets/search-Cv6JxibE.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BeqTD_ES.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C4lnudJI.js",
			"/assets/utils-euZyg2Yx.js",
			"/assets/public-shell-BzdRDkHc.js",
			"/assets/empty-state-3n2cqGHb.js",
			"/assets/section-head-UpzIE76B.js",
			"/assets/button-vIuMDBg7.js",
			"/assets/featured-match-BwHqwQJF.js",
			"/assets/safe-img-D32nIdld.js",
			"/assets/player-card-BIBh9fTg.js"
		]
	},
	"/hq": {
		filePath: "/workspace/src/routes/hq/route.tsx",
		children: [
			"/hq/achievements",
			"/hq/gallery",
			"/hq/insights",
			"/hq/match-day",
			"/hq/matches",
			"/hq/players",
			"/hq/profile",
			"/hq/seasons",
			"/hq/settings",
			"/hq/"
		],
		preloads: [
			"/assets/route-Dod-CuSm.js",
			"/assets/hq-XrHzRq8A.js",
			"/assets/use-current-user-DQB55Vmc.js",
			"/assets/button-vIuMDBg7.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-zIHwHUW_.js",
			"/assets/utils-euZyg2Yx.js",
			"/assets/public-shell-BzdRDkHc.js"
		]
	},
	"/achievements": {
		filePath: "/workspace/src/routes/achievements.tsx",
		children: void 0,
		preloads: [
			"/assets/achievements-CQ6UvN6a.js",
			"/assets/public-shell-BzdRDkHc.js",
			"/assets/empty-state-3n2cqGHb.js",
			"/assets/section-head-UpzIE76B.js",
			"/assets/season-switch-CuOv8PbN.js"
		]
	},
	"/gallery": {
		filePath: "/workspace/src/routes/gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/gallery-Dq3-0L55.js",
			"/assets/x-DoXn43Yn.js",
			"/assets/utils-euZyg2Yx.js",
			"/assets/public-shell-BzdRDkHc.js",
			"/assets/empty-state-3n2cqGHb.js",
			"/assets/section-head-UpzIE76B.js",
			"/assets/season-switch-CuOv8PbN.js"
		]
	},
	"/insights": {
		filePath: "/workspace/src/routes/insights.tsx",
		children: void 0,
		preloads: [
			"/assets/insights-Bu_fiUf5.js",
			"/assets/public-shell-BzdRDkHc.js",
			"/assets/empty-state-3n2cqGHb.js",
			"/assets/section-head-UpzIE76B.js",
			"/assets/season-switch-CuOv8PbN.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-5tl5ucGD.js",
			"/assets/client-cLw6edTc.js",
			"/assets/field-BTZmtgbU.js",
			"/assets/use-current-user-DQB55Vmc.js",
			"/assets/button-vIuMDBg7.js"
		]
	},
	"/matches": {
		filePath: "/workspace/src/routes/matches.tsx",
		children: ["/matches/$matchId"],
		preloads: [
			"/assets/matches-D59obB0_.js",
			"/assets/public-shell-BzdRDkHc.js",
			"/assets/empty-state-3n2cqGHb.js",
			"/assets/section-head-UpzIE76B.js",
			"/assets/season-switch-CuOv8PbN.js",
			"/assets/featured-match-BwHqwQJF.js"
		]
	},
	"/squad": {
		filePath: "/workspace/src/routes/squad.tsx",
		children: ["/squad/$playerId"],
		preloads: [
			"/assets/squad-C_nK8Qb3.js",
			"/assets/public-shell-BzdRDkHc.js",
			"/assets/empty-state-3n2cqGHb.js",
			"/assets/section-head-UpzIE76B.js",
			"/assets/season-switch-CuOv8PbN.js",
			"/assets/player-card-BIBh9fTg.js"
		]
	},
	"/hq/achievements": {
		filePath: "/workspace/src/routes/hq/achievements.tsx",
		children: void 0,
		preloads: [
			"/assets/achievements-BNBwTnhO.js",
			"/assets/hq-shell-BcY-OTqe.js",
			"/assets/useMutation-B6Sv_Dq3.js",
			"/assets/field-BTZmtgbU.js",
			"/assets/image-field-Dq_FBKmK.js"
		]
	},
	"/hq/gallery": {
		filePath: "/workspace/src/routes/hq/gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/gallery-BeEL5ao3.js",
			"/assets/hq-shell-BcY-OTqe.js",
			"/assets/useMutation-B6Sv_Dq3.js",
			"/assets/field-BTZmtgbU.js",
			"/assets/image-79oAZxsA.js"
		]
	},
	"/hq/insights": {
		filePath: "/workspace/src/routes/hq/insights.tsx",
		children: void 0,
		preloads: [
			"/assets/insights-CTZ-NxdH.js",
			"/assets/hq-shell-BcY-OTqe.js",
			"/assets/field-BTZmtgbU.js"
		]
	},
	"/hq/match-day": {
		filePath: "/workspace/src/routes/hq/match-day.tsx",
		children: void 0,
		preloads: [
			"/assets/match-day-DmxvimcR.js",
			"/assets/hq-shell-BcY-OTqe.js",
			"/assets/useMutation-B6Sv_Dq3.js",
			"/assets/field-BTZmtgbU.js"
		]
	},
	"/hq/matches": {
		filePath: "/workspace/src/routes/hq/matches.tsx",
		children: void 0,
		preloads: [
			"/assets/matches-B8MVM4g-.js",
			"/assets/hq-shell-BcY-OTqe.js",
			"/assets/useMutation-B6Sv_Dq3.js",
			"/assets/field-BTZmtgbU.js",
			"/assets/status-pill-DM5Wies8.js"
		]
	},
	"/hq/players": {
		filePath: "/workspace/src/routes/hq/players.tsx",
		children: void 0,
		preloads: [
			"/assets/players-BJ8u3e0v.js",
			"/assets/hq-shell-BcY-OTqe.js",
			"/assets/useMutation-B6Sv_Dq3.js",
			"/assets/field-BTZmtgbU.js",
			"/assets/image-field-Dq_FBKmK.js"
		]
	},
	"/hq/profile": {
		filePath: "/workspace/src/routes/hq/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-D-9ZRFB0.js",
			"/assets/hq-shell-BcY-OTqe.js",
			"/assets/useMutation-B6Sv_Dq3.js",
			"/assets/field-BTZmtgbU.js",
			"/assets/image-field-Dq_FBKmK.js"
		]
	},
	"/hq/seasons": {
		filePath: "/workspace/src/routes/hq/seasons.tsx",
		children: void 0,
		preloads: [
			"/assets/seasons-o1kR62aM.js",
			"/assets/hq-shell-BcY-OTqe.js",
			"/assets/useMutation-B6Sv_Dq3.js",
			"/assets/field-BTZmtgbU.js"
		]
	},
	"/hq/settings": {
		filePath: "/workspace/src/routes/hq/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-B7QW2a_W.js",
			"/assets/hq-shell-BcY-OTqe.js",
			"/assets/useMutation-B6Sv_Dq3.js",
			"/assets/field-BTZmtgbU.js",
			"/assets/image-field-Dq_FBKmK.js"
		]
	},
	"/matches/$matchId": {
		filePath: "/workspace/src/routes/matches.$matchId.tsx",
		children: void 0,
		preloads: [
			"/assets/matches._matchId-CbPTydb0.js",
			"/assets/utils-euZyg2Yx.js",
			"/assets/button-vIuMDBg7.js",
			"/assets/status-pill-DM5Wies8.js",
			"/assets/format-DVr6sjC1.js"
		]
	},
	"/squad/$playerId": {
		filePath: "/workspace/src/routes/squad.$playerId.tsx",
		children: void 0,
		preloads: [
			"/assets/squad._playerId-w0NVUise.js",
			"/assets/utils-euZyg2Yx.js",
			"/assets/button-vIuMDBg7.js",
			"/assets/safe-img-D32nIdld.js"
		]
	},
	"/hq/": {
		filePath: "/workspace/src/routes/hq/index.tsx",
		children: void 0,
		preloads: [
			"/assets/hq-Bm_Wbma5.js",
			"/assets/hq-shell-BcY-OTqe.js",
			"/assets/status-pill-DM5Wies8.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
